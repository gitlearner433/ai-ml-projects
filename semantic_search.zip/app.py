import streamlit as st
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
import numpy as np

# --- Step 1: Product dataset ---
products = [
    "Nike Running Shoes",
    "Adidas Sneakers",
    "Puma Sports T-shirt",
    "Apple iPhone 14",
    "Samsung Galaxy S23",
    "Sony Headphones",
    "Levi's Jeans",
    "Under Armour Hoodie",
]

# --- Step 2: Load embedding model ---
@st.cache_resource
def load_model():
    return SentenceTransformer("all-MiniLM-L6-v2")

model = load_model()

# --- Step 3: Encode product names ---
product_embeddings = model.encode(products)

# --- Step 4: Semantic search function ---
def semantic_search(query, top_k=3):
    query_embedding = model.encode([query])
    similarities = cosine_similarity(query_embedding, product_embeddings)[0]
    top_indices = np.argsort(similarities)[::-1][:top_k]
    results = [(products[idx], round(similarities[idx], 2)) for idx in top_indices]
    return results

# --- Step 5: Streamlit UI ---
st.title("🧠 Simple Semantic Search")
st.write("Type a product-related query and discover the most relevant items!")

query = st.text_input("Enter your search query:")

if query:
    results = semantic_search(query)
    st.subheader("🔍 Top Matches")
    for product, score in results:
        st.write(f"- **{product}** (score: {score})")