import streamlit as st
from id3 import id3

# Same dataset
dataset = [
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Self-Employed", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Self-Employed", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Salaried", "IncomeLevel": "Medium", "Collateral": "No", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Salaried", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "Medium", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Self-Employed", "IncomeLevel": "Medium", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Salaried", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Self-Employed", "IncomeLevel": "Medium", "Collateral": "No", "LoanStatus": "Rejected"},
]

attributes = ["CreditScore", "EmploymentType", "IncomeLevel", "Collateral"]
target = "LoanStatus"

tree = id3(dataset, attributes, target)

st.title("Loan Prediction using ID3")
credit = st.selectbox("Credit Score", ["Good", "Average", "Poor"])
employment = st.selectbox("Employment Type", ["Salaried", "Self-Employed"])
income = st.selectbox("Income Level", ["High", "Medium", "Low"])
collateral = st.selectbox("Collateral", ["Yes", "No"])

if st.button("Predict"):
    sample = {"CreditScore": credit, "EmploymentType": employment, "IncomeLevel": income, "Collateral": collateral}
    
    def classify(tree, sample):
        if not isinstance(tree, dict):
            return tree
        attr = list(tree.keys())[0]
        value = sample[attr]
        if value in tree[attr]:
            return classify(tree[attr][value], sample)
        else:
            return "Unknown"
    
    result = classify(tree, sample)
    st.success(f"Loan Prediction: {result}")
