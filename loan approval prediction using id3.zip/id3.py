import math
from collections import Counter

# Calculate entropy
def entropy(data, target_attr):
    values = [record[target_attr] for record in data]
    freq = Counter(values)
    total = len(values)
    return -sum((count/total) * math.log2(count/total) for count in freq.values())

# Calculate information gain
def info_gain(data, attr, target_attr):
    total_entropy = entropy(data, target_attr)
    values = set(record[attr] for record in data)
    subset_entropy = 0
    total = len(data)

    for value in values:
        subset = [record for record in data if record[attr] == value]
        subset_entropy += (len(subset)/total) * entropy(subset, target_attr)

    return total_entropy - subset_entropy

# Find best attribute
def best_attribute(data, attributes, target_attr):
    gains = {attr: info_gain(data, attr, target_attr) for attr in attributes}
    return max(gains, key=gains.get), gains

# ID3 recursive tree building
def id3(data, attributes, target_attr):
    values = [record[target_attr] for record in data]
    if values.count(values[0]) == len(values):
        return values[0]
    if not attributes:
        return Counter(values).most_common(1)[0][0]

    best_attr, _ = best_attribute(data, attributes, target_attr)
    tree = {best_attr: {}}

    for value in set(record[best_attr] for record in data):
        subset = [record for record in data if record[best_attr] == value]
        if not subset:
            tree[best_attr][value] = Counter(values).most_common(1)[0][0]
        else:
            remaining_attrs = [attr for attr in attributes if attr != best_attr]
            tree[best_attr][value] = id3(subset, remaining_attrs, target_attr)

    return tree
