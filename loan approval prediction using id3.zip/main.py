from id3 import entropy, info_gain, id3, best_attribute
import matplotlib.pyplot as plt
import networkx as nx

# Dataset directly in code
dataset = [
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Self-Employed", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Self-Employed", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Salaried", "IncomeLevel": "Medium", "Collateral": "No", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Salaried", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "Medium", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Self-Employed", "IncomeLevel": "Medium", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Poor", "EmploymentType": "Salaried", "IncomeLevel": "Low", "Collateral": "No", "LoanStatus": "Rejected"},
    {"CreditScore": "Good", "EmploymentType": "Salaried", "IncomeLevel": "High", "Collateral": "Yes", "LoanStatus": "Approved"},
    {"CreditScore": "Average", "EmploymentType": "Self-Employed", "IncomeLevel": "Medium", "Collateral": "No", "LoanStatus": "Rejected"},
]

attributes = ["CreditScore", "EmploymentType", "IncomeLevel", "Collateral"]
target = "LoanStatus"

# 1. Compute Entropy
print(f"Entropy of LoanStatus: {entropy(dataset, target):.4f}")

# 2. Information Gain for all attributes
for attr in attributes:
    print(f"Info Gain({attr}): {info_gain(dataset, attr, target):.4f}")

# 3. Build Decision Tree
tree = id3(dataset, attributes, target)
print("\nDecision Tree:", tree)

# 4. Visualize Decision Tree using NetworkX
def plot_tree(tree, parent_name='', graph=None):
    if graph is None:
        graph = nx.DiGraph()

    for attr, branches in tree.items():
        for value, subtree in branches.items():
            node_name = f"{attr} = {value}"
            graph.add_edge(parent_name, node_name if isinstance(subtree, dict) else f"{node_name} → {subtree}")
            if isinstance(subtree, dict):
                plot_tree(subtree, node_name, graph)

    return graph

graph = plot_tree(tree, "Loan Prediction")
pos = nx.spring_layout(graph)
nx.draw(graph, pos, with_labels=True, node_size=3000, node_color="lightblue", font_size=9)
plt.show()
